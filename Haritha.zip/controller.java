package qwerty.indua;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;
@RestController
public class controller {
    @GetMapping("/hello")
    public String hello() {
        return "<!DOCTYPE html> \r\n" + //
        "<html>\r\n" + //
        "<head> \r\n" + //
            "<title>Document</title>\r\n" + //
        "</head> \r\n" + //
        "<body> \r\n" + //
            "<h1>Welcsome to the clas</h1>\r\n" + //
        "</body>\r\n" + //
        "</html> \r\n" + //
        ";
    }
}